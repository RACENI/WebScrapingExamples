package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvenApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvenApplication.class, args);
	}

}
